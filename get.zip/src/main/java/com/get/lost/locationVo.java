package com.get.lost;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class locationVo {
	private int location_code;
	private String sido_name;
	private String gugun_name;
}
